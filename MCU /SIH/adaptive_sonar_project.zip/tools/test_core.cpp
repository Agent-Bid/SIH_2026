// Host-side tests for sonar_core.h. Build: g++ -std=c++11 -O1 -I../adaptive_sonar test_core.cpp -o test_core
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include "sonar_core.h"
#include "ml_model.h"
using namespace sonar;
static int fails = 0;
#define CHECK(cond, msg) do { if (!(cond)) { printf("  FAIL: %s\n", msg); fails++; } else printf("  ok:   %s\n", msg); } while (0)
static bool near(float a, float b, float tol) { return fabsf(a - b) <= tol; }

int main(int argc, char **argv) {
  printf("== unit checks ==\n");
  CHECK(near(soundSpeedMackenzie(25, 35, 1000), 1550.744f, 0.01f), "Mackenzie check value 1550.744 m/s (T25,S35,D1000)");
  // Francois-Garrison vs independent implementation (MB-System 'mbabsorption' logic, with the corrected 4.937e-4 term):
  // f=200k T=4 S=35 D=1000 pH=8 c=1483.19  ->  39.7709 dB/km
  CHECK(near(fgAbsorptionDbKm(200, 4, 35, 1000, 8, 1483.19f), 39.7709f, 0.02f), "Francois-Garrison 200 kHz reference point");
  // continuity of pure-water term at T = 20 C (catches the 4.397e-4 vs 4.937e-4 typo)
  float lo = fgAbsorptionDbKm(300, 19.999f, 35, 0, 8, 1520), hi = fgAbsorptionDbKm(300, 20.001f, 35, 0, 8, 1520);
  CHECK(near(lo, hi, 0.05f), "Francois-Garrison continuous across T = 20 C");
  CHECK(fgAbsorptionDbKm(500, 15, 35, 50, 8, 1507) > fgAbsorptionDbKm(100, 15, 35, 50, 8, 1507), "absorption grows with frequency");
  CHECK(near(ambientNoiseDb(100.0f), 28.9f, 0.3f), "ambient noise at 100 kHz = thermal + wind (~28.9 dB)");
  CHECK(ambientNoiseDb(500.0f) > ambientNoiseDb(200.0f), "thermal noise dominates and rises with frequency above 100 kHz");
  const uint8_t msg[] = { '1','2','3','4','5','6','7','8','9' };
  CHECK(crc8(msg, 9) == 0xF4, "CRC-8 (poly 0x07) standard check value 0xF4");
  CHECK(sizeof(SonarPacket) == 57, "packet is 57 bytes");
  // FPGA units, against values worked out independently in Python (Basic-finished/host/mcu_packet.py)
  { struct Want { int prof; int mod; uint32_t len, start; int32_t step; uint32_t win; uint16_t code; uint32_t chip; };
    const Want want[] = {
      {  0, MOD_LFM_CHIRP,   50143, 32548755, 13433886, 85654,      0,     0 },   // X-S
      {  0, MOD_GEOMETRIC,   50143, 32548755,   752746, 85654,      0,     0 },
      {  0, MOD_BPSK,        50141, 37688032,        0, 85658, 0x0A60,  3857 },
      { 11, MOD_LFM_CHIRP, 1002857,  8565462,   223899,  4283,      0,     0 },   // L-L
      { 11, MOD_GEOMETRIC, 1002857,  8565462,    46113,  4283,      0,     0 },
      { 11, MOD_BPSK,      1002859, 10278554,        0,  4283, 0x0A60, 77143 } };
    bool ok = true;
    for (const Want &e : want) {
      FpgaWave w = fpgaWave(withModulation(PROFILES[e.prof], e.mod));
      ok = ok && w.fits && w.lenClk == e.len && w.ftwStart == e.start && w.ftwStep == e.step
              && w.winStep == e.win && w.code == e.code && w.chipLen == e.chip;
    }
    CHECK(ok, "X-S and L-L as LFM, geometric and BPSK in FPGA units match Python"); }
  { double worst = 0;                       // the LFM sweep must cover the whole bandwidth
    for (int i = 0; i < NUM_PROFILES; i++) {
      const WaveProfile &p = PROFILES[i]; FpgaWave w = fpgaWave(p);
      const double bw = (double)w.ftwStep / 65536.0 * w.lenClk * FPGA_CLK_HZ / 4294967296.0;
      worst = fmax(worst, fabs(bw / p.bwHz - 1)); }
    CHECK(worst < 1e-4, "every chirp sweeps its full bandwidth within 0.01% (fractional step bits)"); }
  { bool ok = true;                         // BPSK: 13 whole chips fill the pulse
    for (int i = 0; i < NUM_PROFILES; i++) {
      FpgaWave w = fpgaWave(withModulation(PROFILES[i], MOD_BPSK));
      ok = ok && w.chipLen * 13 == w.lenClk && w.code == 0x0A60; }
    CHECK(ok, "BPSK: Barker-13 with 13 whole chips per pulse, for every profile"); }
  int bad; CHECK(validateProfiles(&bad), "all profiles inside 100-500 kHz band");

  printf("== behaviour sweeps ==\n");
  Env base = { 15, 35, 50, 20, 100 };
  { int prev = -1; bool mono = true;
    for (int R = 10; R <= 2000; R += 10) { Decision d = decide(base, R, -1, -1); if (d.profile < prev) mono = false; prev = d.profile; }
    CHECK(mono, "longer range never picks a finer-resolution profile"); }
  { int prev = -1; bool mono = true;
    for (int b = 100; b >= 0; b -= 5) { Env e = base; e.batteryPct = b; Decision d = decide(e, 400, -1, -1); if (d.profile < prev) mono = false; prev = d.profile; }
    CHECK(mono, "lower battery never picks a finer-resolution profile"); }
  { int prev = -1; bool mono = true;
    for (int t = 0; t <= 100; t += 5) { Env e = base; e.turbidityNtu = t; Decision d = decide(e, 400, -1, -1); if (d.profile < prev) mono = false; prev = d.profile; }
    CHECK(mono, "higher turbidity never picks a finer-resolution profile"); }
  { Env e = { 30, 40, 0, 100, 10 }; Decision d = decide(e, 2000, -1, -1);
    CHECK((d.flags & FLAG_BEST_EFFORT) && !(d.flags & FLAG_LINK_OK) && d.profile == NUM_PROFILES - 1, "extreme case -> BEST_EFFORT on last profile"); }
  { Env e = { NAN, 99, -5, 500, 150 }; Decision d = decide(e, 5, -1, -1);
    CHECK((d.flags & FLAG_INPUT_CLAMPED) && d.profile >= 0 && d.profile < NUM_PROFILES, "NaN / out-of-range inputs are sanitised"); }
  { Decision d = decide(base, 300, -1, -1); int hint = NUM_PROFILES - 1; Decision m = decide(base, 300, -1, hint);
    CHECK((m.flags & FLAG_ML_USED) && m.profile == hint, "feasible ML hint accepted");
    Env hard = { 30, 40, 0, 100, 10 }; Decision o = decide(hard, 1500, -1, 0);
    CHECK((o.flags & FLAG_ML_OVERRIDDEN) && !(o.flags & FLAG_ML_USED), "infeasible ML hint overridden by physics"); (void)d; }
  { Decision d = decide(base, 300, -1, -1); SonarPacket k = buildPacket(d, 7);
    CHECK(k.crc8 == crc8((const uint8_t *)&k, sizeof(k) - 1) && k.sync == 0xA5, "packet CRC / sync valid");
    const WaveProfile &p = PROFILES[d.profile];
    CHECK(k.centerFreqHz == (uint32_t)p.fcHz && k.bandwidthHz == (uint32_t)p.bwHz, "packet carries profile frequency/bandwidth");
    FpgaWave w = fpgaWave(p);
    CHECK(k.version == 3 && k.lenClk == w.lenClk && k.ftwStart == w.ftwStart && k.ftwStep == w.ftwStep
          && k.winStep == w.winStep && k.ampQ12 == (uint16_t)lroundf(d.ampFrac * 4096.0f)
          && k.periodClk == 5014286 && k.periodClk > k.lenClk, "packet carries the FPGA-unit fields and a 100 ms period");
    SonarPacket g = buildPacket(d, 7, MOD_BPSK);
    CHECK(g.modulation == MOD_BPSK && g.code == 0x0A60 && g.chipLen * 13 == g.lenClk && g.ftwStep == 0
          && g.crc8 == crc8((const uint8_t *)&g, sizeof(g) - 1), "M bpsk override: BPSK packet with a valid CRC"); }
  { Decision d = decide(base, 300, -1, -1);
    CHECK(d.maxRangeM >= 300.0f || !(d.flags & FLAG_LINK_OK), "reach >= target range when link OK"); }

  printf("== detail vs energy rule ==\n");
  { // clear water, 600 m: the finest profile (H-M) would cost ~30x more energy than M-S, which has
    // enough detail and fits the allowance
    Env e = { 10, 35, 50, 5, 100 };
    Decision d = decide(e, 600, -1, -1);
    bool finerFits = false;
    const float c = soundSpeedMackenzie(e.tempC, e.salinityPpt, e.depthM);
    for (int i = 0; i < d.profile; i++) {
      Eval ev = evaluateProfile(PROFILES[i], e, c, 600, energyBudgetJ(e.batteryPct), 0.0f);
      if (ev.feasible && ev.pUseW * PROFILES[i].pulseS <= d.energyAllowanceJ) finerFits = true;
    }
    CHECK((d.flags & FLAG_LINK_OK) && d.energyJ <= d.energyAllowanceJ && !finerFits && d.profile == 6,
          "600 m: finest profile within the energy allowance (M-S), not the finest that works (H-M)");
    Env low = e; low.batteryPct = 15;
    CHECK(decide(low, 600, -1, -1).profile > d.profile, "a low battery leans towards saving energy (coarser profile)"); }
  { // the anti flip-flop margin also holds for an ML pick that flips every time (worst case)
    Env e = base;
    int r0 = -1, a = decide(e, 20, -1, -1).profile;
    for (int R = 21; R <= 2000 && r0 < 0; R++) { int b = decide(e, (float)R, -1, -1).profile; if (b != a) r0 = R - 1; a = b; }
    int prev = -1, switches = 0, hintFlips = 0, lastHint = -1;
    for (int n = 0; n < 60 && r0 > 0; n++) {
      const float R = r0 + 0.5f + ((n & 1) ? 0.6f : -0.6f);          // jitter across the boundary
      const int hint = decide(e, R, -1, -1).profile;                  // an ML with no hysteresis
      if (lastHint >= 0 && hint != lastHint) hintFlips++;
      lastHint = hint;
      Decision d = decide(e, R, prev, hint);
      if (prev >= 0 && d.profile != prev) switches++;
      prev = d.profile;
    }
    printf("  boundary at %d m: the ML hint flipped %d times, the chosen profile %d times\n", r0, hintFlips, switches);
    CHECK(r0 > 0 && hintFlips >= 50 && switches <= 1, "jitter at a profile boundary: no flip-flop, even with the ML"); }

  printf("== ML model (ml_model.h) ==\n");
  { // the C networks against the Python models, on ../ml/test_vectors.csv
    FILE *f = fopen("../ml/test_vectors.csv", "r"); char line[256]; int n = 0, same = 0, close_call = 0, ampOk = 0;
    while (f && fgets(line, sizeof line, f)) {
      float x[6], amp; int k; double margin;
      if (sscanf(line, "%f,%f,%f,%f,%f,%f,%d,%lf,%f", &x[0], &x[1], &x[2], &x[3], &x[4], &x[5], &k, &margin, &amp) != 9) continue;
      n++;
      const int p = ml::ml_predict_profile(x);
      if (p == k) same++;
      else if (margin < 1e-3) close_call++;     // two classes scored almost the same: rounding may flip it
      if (p == k && fabsf(ml::ml_predict_amplitude(x, k) - amp) <= 1e-4f * amp + 1e-6f) ampOk++;
    }
    if (f) fclose(f);
    printf("  vectors=%d  same profile=%d  close calls=%d  same amplitude=%d\n", n, same, close_call, ampOk);
    CHECK(n >= 1000 && same + close_call == n, "C classifier gives the Python model's profile on the test vectors");
    CHECK(ampOk == same, "C amplitude network gives the Python model's amplitude on the test vectors"); }
  { // the ML decides through sonar::decide()
    const float in[6] = { base.tempC, base.salinityPpt, base.depthM, base.turbidityNtu, base.batteryPct, 300.0f };
    const int hint = ml::ml_predict_profile(in);
    const float amp = ml::ml_predict_amplitude(in, hint);
    Decision phys = decide(base, 300, -1, -1);
    Decision d = decide(base, 300, -1, hint, amp);
    CHECK((d.flags & FLAG_ML_USED) && d.profile == phys.profile && d.ampFrac >= phys.ampFrac - 1e-6f
          && d.ampFrac <= phys.ampFrac * 1.2f,
          "base scenario (300 m): the ML's profile and amplitude are used, amplitude enough but not wasteful");
    Decision low = decide(base, 300, -1, phys.profile, 0.0f);
    CHECK((low.flags & FLAG_ML_AMP_RAISED) && fabsf(low.ampFrac - phys.ampFrac) < 1e-6f,
          "an ML amplitude that is too low is raised to what the link needs"); }

  if (argc > 1) {
    printf("== C++ vs Python reference (%s) ==\n", argv[1]);
    FILE *f = fopen(argv[1], "r"); char line[512]; int n = 0, profMis = 0, ampBad = 0, snrBad = 0; double maxSnr = 0, maxAmp = 0;
    while (f && fgets(line, sizeof line, f)) {
      double T, S, D, tb, soc, R, ea, es; int prev, ep, eok;
      if (sscanf(line, "%lf,%lf,%lf,%lf,%lf,%lf,%d,%d,%d,%lf,%lf", &T, &S, &D, &tb, &soc, &R, &prev, &ep, &eok, &ea, &es) != 11) continue;
      Env e = { (float)T, (float)S, (float)D, (float)tb, (float)soc };
      Decision d = decide(e, (float)R, prev, -1); n++;
      if (d.profile != ep) { profMis++; continue; }
      double da = fabs(d.ampFrac - ea), ds = fabs(d.snrOutDb - es);
      if (da > maxAmp) { maxAmp = da; }
      if (ds > maxSnr) { maxSnr = ds; }
      if (da > 2e-3) { ampBad++; }
      if (ds > 0.02) { snrBad++; }
    }
    if (f) fclose(f);
    printf("  vectors=%d  profile mismatches=%d (%.3f%%)  amp>2e-3: %d  snr>0.02dB: %d  max|d amp|=%.2e max|d snr|=%.2e dB\n",
           n, profMis, 100.0 * profMis / (n ? n : 1), ampBad, snrBad, maxAmp, maxSnr);
    CHECK(n >= 4000, "reference vectors loaded");
    CHECK(profMis <= n / 200, "profile choice matches Python (<=0.5% float/double boundary flips)");
    CHECK(ampBad == 0 && snrBad == 0, "amplitude and SNR match Python within tolerance");
  }
  printf("\n%s (%d failures)\n", fails ? "TESTS FAILED" : "ALL TESTS PASSED", fails);
  return fails ? 1 : 0;
}
