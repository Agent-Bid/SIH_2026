// Minimal host mock of Arduino-ESP32 + FreeRTOS, ONLY for syntax/type checking the .ino on a PC.
#pragma once
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
typedef void* QueueHandle_t; typedef uint32_t TickType_t; typedef int BaseType_t;
#define pdTRUE 1
#define pdMS_TO_TICKS(x) ((TickType_t)(x))
#define OUTPUT 1
#define HIGH 1
#define LOW 0
#define ADC_11db 3
#define MSBFIRST 1
#define SPI_MODE0 0
#define FSPI 0
inline uint32_t millis() { return 0; }
inline void delay(uint32_t) {}
inline void pinMode(int,int) {}
inline void digitalWrite(int,int) {}
inline uint32_t analogReadMilliVolts(int) { return 1500; }
inline void analogReadResolution(int) {}
inline void analogSetAttenuation(int) {}
inline TickType_t xTaskGetTickCount() { return 0; }
inline void vTaskDelay(TickType_t) {}
inline void vTaskDelayUntil(TickType_t*, TickType_t) {}
inline QueueHandle_t xQueueCreate(int, int) { return (void*)1; }
inline BaseType_t xQueueOverwrite(QueueHandle_t, const void*) { return 1; }
inline BaseType_t xQueuePeek(QueueHandle_t, void*, TickType_t) { return 0; }
inline BaseType_t xQueueReceive(QueueHandle_t, void*, TickType_t) { return 0; }
inline BaseType_t xQueueSend(QueueHandle_t, const void*, TickType_t) { return 1; }
inline BaseType_t xTaskCreatePinnedToCore(void(*)(void*), const char*, uint32_t, void*, int, void*, int) { return 1; }
typedef int portMUX_TYPE;
#define portMUX_INITIALIZER_UNLOCKED 0
#define portENTER_CRITICAL(m) ((void)(m))
#define portEXIT_CRITICAL(m) ((void)(m))
struct SPISettings { SPISettings(uint32_t,int,int){} };
struct SerialMock {
  void begin(int) {}
  size_t setTxBufferSize(size_t n) { return n; }
  int available() { return 0; }
  int read() { return -1; }
  void print(const char* s) { fputs(s, stdout); }
  void flush() {}
  int availableForWrite() { return 256; }
  size_t write(const uint8_t* b, size_t n) { return fwrite(b, 1, n, stdout); }
  void println(const char* s) { puts(s); }
  void printf(const char* f, ...) { va_list a; va_start(a,f); vprintf(f,a); va_end(a); }
};
static SerialMock Serial;
