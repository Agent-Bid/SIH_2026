import random, physics_reference as r
rnd = random.Random(7); C = r.CFG
with open("vectors.csv", "w") as f:
    for _ in range(5000):
        env = dict(T=rnd.uniform(C["TEMP_MIN_C"], C["TEMP_MAX_C"]), S=rnd.uniform(C["SALINITY_MIN_PPT"], C["SALINITY_MAX_PPT"]),
                   D=rnd.uniform(C["DEPTH_MIN_M"], C["DEPTH_MAX_M"]), turb=rnd.uniform(0, 100), soc=rnd.uniform(0, 100))
        R = rnd.uniform(10, 2000); prev = rnd.choice([-1, -1, rnd.randrange(len(r.PROFILES))])
        i, ok, ev, c = r.decide(env, R, prev)
        f.write(f"{env['T']:.5f},{env['S']:.5f},{env['D']:.4f},{env['turb']:.5f},{env['soc']:.5f},{R:.4f},{prev},{i},{int(ok)},{ev['amp']:.6f},{ev['snr']:.5f}\n")
print("5000 vectors written")
