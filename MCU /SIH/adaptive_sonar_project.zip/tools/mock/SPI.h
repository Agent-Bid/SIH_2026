#pragma once
#include "Arduino.h"
struct SPIClass {
  SPIClass(int) {}
  void begin(int,int,int,int) {}
  void beginTransaction(SPISettings) {}
  void endTransaction() {}
  void writeBytes(const uint8_t*, uint32_t) {}
};
