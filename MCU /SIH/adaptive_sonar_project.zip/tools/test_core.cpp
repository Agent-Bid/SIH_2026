// Host-side tests for sonar_core.h. Build: g++ -std=c++11 -O1 -I../adaptive_sonar test_core.cpp -o test_core
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include "sonar_core.h"
#include "ml_model.h"
#include "water_sim.h"
using namespace sonar;
static int fails = 0;
#define CHECK(cond, msg) do { if (!(cond)) { printf("  FAIL: %s\n", msg); fails++; } else printf("  ok:   %s\n", msg); } while (0)
static bool near(float a, float b, float tol) { return fabsf(a - b) <= tol; }

int main(int argc, char **argv) {
  printf("== unit checks ==\n");
  CHECK(near(soundSpeedMackenzie(25, 35, 1000), 1550.744f, 0.01f), "Mackenzie check value 1550.744 m/s (T25,S35,D1000)");
  // Francois-Garrison vs independent implementation (MB-System 'mbabsorption' logic, with the corrected 4.937e-4 term):
  // f=200k T=4 S=35 D=1000 pH=8 c=1483.19  ->  39.7709 dB/km
  CHECK(near(fgAbsorptionDbKm(200, 4, 35, 1000, 8, 1483.19f), 39.7709f, 0.02f), "Francois-Garrison 200 kHz reference point");
  // continuity of pure-water term at T = 20 C (catches the 4.397e-4 vs 4.937e-4 typo)
  float lo = fgAbsorptionDbKm(300, 19.999f, 35, 0, 8, 1520), hi = fgAbsorptionDbKm(300, 20.001f, 35, 0, 8, 1520);
  CHECK(near(lo, hi, 0.05f), "Francois-Garrison continuous across T = 20 C");
  CHECK(fgAbsorptionDbKm(500, 15, 35, 50, 8, 1507) > fgAbsorptionDbKm(100, 15, 35, 50, 8, 1507), "absorption grows with frequency");
  CHECK(near(ambientNoiseDb(100.0f), 28.9f, 0.3f), "ambient noise at 100 kHz = thermal + wind (~28.9 dB)");
  CHECK(ambientNoiseDb(500.0f) > ambientNoiseDb(200.0f), "thermal noise dominates and rises with frequency above 100 kHz");
  const uint8_t msg[] = { '1','2','3','4','5','6','7','8','9' };
  CHECK(crc8(msg, 9) == 0xF4, "CRC-8 (poly 0x07) standard check value 0xF4");
  CHECK(sizeof(SonarPacket) == 57, "packet is 57 bytes");
  // FPGA units, against values worked out independently in Python (Basic-finished/host/mcu_packet.py)
  { struct Want { int prof; int mod; uint32_t len, start; int32_t step; uint32_t win; uint16_t code; uint32_t chip; };
    const Want want[] = {
      {  0, MOD_LFM_CHIRP,   50143, 32548755, 13433886, 85654,      0,     0 },   // X-S
      {  0, MOD_GEOMETRIC,   50143, 32548755,   752746, 85654,      0,     0 },
      {  0, MOD_BPSK,        50141, 37688032,        0, 85658, 0x0A60,  3857 },
      { 11, MOD_LFM_CHIRP, 1002857,  8565462,   223899,  4283,      0,     0 },   // L-L
      { 11, MOD_GEOMETRIC, 1002857,  8565462,    46113,  4283,      0,     0 },
      { 11, MOD_BPSK,      1002859, 10278554,        0,  4283, 0x0A60, 77143 } };
    bool ok = true;
    for (const Want &e : want) {
      FpgaWave w = fpgaWave(withModulation(PROFILES[e.prof], e.mod));
      ok = ok && w.fits && w.lenClk == e.len && w.ftwStart == e.start && w.ftwStep == e.step
              && w.winStep == e.win && w.code == e.code && w.chipLen == e.chip;
    }
    CHECK(ok, "X-S and L-L as LFM, geometric and BPSK in FPGA units match Python"); }
  { double worst = 0;                       // the LFM sweep must cover the whole bandwidth
    for (int i = 0; i < NUM_PROFILES; i++) {
      const WaveProfile &p = PROFILES[i]; FpgaWave w = fpgaWave(p);
      const double bw = (double)w.ftwStep / 65536.0 * w.lenClk * FPGA_CLK_HZ / 4294967296.0;
      worst = fmax(worst, fabs(bw / p.bwHz - 1)); }
    CHECK(worst < 1e-4, "every chirp sweeps its full bandwidth within 0.01% (fractional step bits)"); }
  { bool ok = true;                         // BPSK: 13 whole chips fill the pulse
    for (int i = 0; i < NUM_PROFILES; i++) {
      FpgaWave w = fpgaWave(withModulation(PROFILES[i], MOD_BPSK));
      ok = ok && w.chipLen * 13 == w.lenClk && w.code == 0x0A60; }
    CHECK(ok, "BPSK: Barker-13 with 13 whole chips per pulse, for every profile"); }
  int bad; CHECK(validateProfiles(&bad), "all profiles inside 100-500 kHz band");

  printf("== behaviour sweeps ==\n");
  Env base = { 15, 35, 50, 20, 100, 0 };
  { int prev = -1; bool mono = true;
    for (int R = 10; R <= 2000; R += 10) { Decision d = decide(base, R, -1, -1); if (d.profile < prev) mono = false; prev = d.profile; }
    CHECK(mono, "longer range never picks a finer-resolution profile"); }
  { int prev = -1; bool mono = true;
    for (int b = 100; b >= 0; b -= 5) { Env e = base; e.batteryPct = b; Decision d = decide(e, 400, -1, -1); if (d.profile < prev) mono = false; prev = d.profile; }
    CHECK(mono, "lower battery never picks a finer-resolution profile"); }
  { int prev = -1; bool mono = true;
    for (int t = 0; t <= 100; t += 5) { Env e = base; e.turbidityNtu = t; Decision d = decide(e, 400, -1, -1); if (d.profile < prev) mono = false; prev = d.profile; }
    CHECK(mono, "higher turbidity never picks a finer-resolution profile"); }
  { Env e = { 30, 40, 0, 100, 10, 0 }; Decision d = decide(e, 2000, -1, -1);
    CHECK((d.flags & FLAG_BEST_EFFORT) && !(d.flags & FLAG_LINK_OK) && d.profile == NUM_PROFILES - 1, "extreme case -> BEST_EFFORT on last profile"); }
  { Env e = { NAN, 99, -5, 500, 150, 0 }; Decision d = decide(e, 5, -1, -1);
    CHECK((d.flags & FLAG_INPUT_CLAMPED) && d.profile >= 0 && d.profile < NUM_PROFILES, "NaN / out-of-range inputs are sanitised"); }
  { Decision d = decide(base, 300, -1, -1); int hint = NUM_PROFILES - 1; Decision m = decide(base, 300, -1, hint);
    CHECK((m.flags & FLAG_ML_USED) && m.profile == hint, "feasible ML hint accepted");
    Env hard = { 30, 40, 0, 100, 10, 0 }; Decision o = decide(hard, 1500, -1, 0);
    CHECK((o.flags & FLAG_ML_OVERRIDDEN) && !(o.flags & FLAG_ML_USED), "infeasible ML hint overridden by physics"); (void)d; }
  { Decision d = decide(base, 300, -1, -1); SonarPacket k = buildPacket(d, 7);
    CHECK(k.crc8 == crc8((const uint8_t *)&k, sizeof(k) - 1) && k.sync == 0xA5, "packet CRC / sync valid");
    const WaveProfile &p = PROFILES[d.profile];
    CHECK(k.centerFreqHz == (uint32_t)p.fcHz && k.bandwidthHz == (uint32_t)p.bwHz, "packet carries profile frequency/bandwidth");
    FpgaWave w = fpgaWave(p);
    CHECK(k.version == 3 && k.lenClk == w.lenClk && k.ftwStart == w.ftwStart && k.ftwStep == w.ftwStep
          && k.winStep == w.winStep && k.ampQ12 == (uint16_t)lroundf(d.ampFrac * 4096.0f)
          && k.periodClk == 8357143 && k.periodClk > k.lenClk, "packet carries the FPGA-unit fields and a 1/6 s period (6 pings/s)");
    SonarPacket g = buildPacket(d, 7, MOD_BPSK);
    CHECK(g.modulation == MOD_BPSK && g.code == 0x0A60 && g.chipLen * 13 == g.lenClk && g.ftwStep == 0
          && g.crc8 == crc8((const uint8_t *)&g, sizeof(g) - 1), "M bpsk override: BPSK packet with a valid CRC"); }
  { Decision d = decide(base, 300, -1, -1);
    CHECK(d.maxRangeM >= 300.0f || !(d.flags & FLAG_LINK_OK), "reach >= target range when link OK"); }

  printf("== detail vs energy rule ==\n");
  { // clear water, 600 m: the finest profile (H-M) would cost ~30x more energy than M-S, which has
    // enough detail and fits the allowance
    Env e = { 10, 35, 50, 5, 100, 0 };
    Decision d = decide(e, 600, -1, -1);
    bool finerFits = false;
    const float c = soundSpeedMackenzie(e.tempC, e.salinityPpt, e.depthM);
    for (int i = 0; i < d.profile; i++) {
      Eval ev = evaluateProfile(PROFILES[i], e, c, 600, energyBudgetJ(e.batteryPct), 0.0f);
      if (ev.feasible && ev.pUseW * PROFILES[i].pulseS <= d.energyAllowanceJ) finerFits = true;
    }
    CHECK((d.flags & FLAG_LINK_OK) && d.energyJ <= d.energyAllowanceJ && !finerFits && d.profile == 6,
          "600 m: finest profile within the energy allowance (M-S), not the finest that works (H-M)");
    Env low = e; low.batteryPct = 15;
    CHECK(decide(low, 600, -1, -1).profile > d.profile, "a low battery leans towards saving energy (coarser profile)"); }
  { // the anti flip-flop margin also holds for an ML pick that flips every time (worst case)
    Env e = base;
    int r0 = -1, a = decide(e, 20, -1, -1).profile;
    for (int R = 21; R <= 2000 && r0 < 0; R++) { int b = decide(e, (float)R, -1, -1).profile; if (b != a) r0 = R - 1; a = b; }
    int prev = -1, switches = 0, hintFlips = 0, lastHint = -1;
    for (int n = 0; n < 60 && r0 > 0; n++) {
      const float R = r0 + 0.5f + ((n & 1) ? 0.6f : -0.6f);          // jitter across the boundary
      const int hint = decide(e, R, -1, -1).profile;                  // an ML with no hysteresis
      if (lastHint >= 0 && hint != lastHint) hintFlips++;
      lastHint = hint;
      Decision d = decide(e, R, prev, hint);
      if (prev >= 0 && d.profile != prev) switches++;
      prev = d.profile;
    }
    printf("  boundary at %d m: the ML hint flipped %d times, the chosen profile %d times\n", r0, hintFlips, switches);
    CHECK(r0 > 0 && hintFlips >= 50 && switches <= 1, "jitter at a profile boundary: no flip-flop, even with the ML"); }

  printf("== modulation from motion (Doppler) ==\n");
  { bool still = true, order = true;
    const int rank[4] = { -1, 1, 2, 0 };                     // BPSK < LFM < geometric in tolerance
    for (int i = 0; i < NUM_PROFILES; i++) {
      int last = -1;
      for (float v = 0.0f; v <= SPEED_MAX_MS; v += 0.05f) {
        Decision d = decide(base, 300, -1, -1); d.profile = i;
        Env e = base; e.speedMs = v; chooseModulation(d, e);
        if (v == 0.0f && d.mod != MOD_BPSK) still = false;
        if (rank[d.mod] < last) order = false;
        last = rank[d.mod];
      }
    }
    CHECK(still, "no motion: BPSK for every profile");
    CHECK(order, "more speed never picks a less Doppler-tolerant modulation (BPSK -> LFM -> geometric)"); }
  { // X-S (440 kHz, 1 ms), c ~ 1507 m/s: drift = speed x 0.292 cycles per m/s
    Decision d = decide(base, 300, -1, -1); d.profile = 0; d.soundSpeed = soundSpeedMackenzie(15, 35, 50);
    Env e = base;
    e.speedMs = 0.5f; chooseModulation(d, e); const int m1 = d.mod; const float c1 = d.dopplerCycles;
    e.speedMs = 2.0f; chooseModulation(d, e); const int m2 = d.mod;
    e.speedMs = 5.0f; chooseModulation(d, e); const int m3 = d.mod;
    CHECK(near(c1, 0.5f * 440000.0f * 0.001f / d.soundSpeed, 1e-5f) && m1 == MOD_BPSK && m2 == MOD_LFM_CHIRP
          && m3 == MOD_GEOMETRIC, "X-S: 0.5 m/s -> BPSK (0.15 cycles), 2 m/s -> LFM (0.58), 5 m/s -> geometric (1.46)"); }
  { Decision d = decide(base, 300, -1, -1); Env e = base; e.speedMs = 5.0f;
    chooseModulation(d, e, MOD_BPSK);
    CHECK((d.flags & FLAG_ML_MOD_OVERRIDDEN) && d.mod == modulationFor(d.dopplerCycles) && d.mod != MOD_BPSK,
          "ML modulation that cannot take the motion is replaced");
    Decision s2 = decide(base, 300, -1, -1); Env still = base;
    chooseModulation(s2, still, MOD_GEOMETRIC);
    CHECK(!(s2.flags & FLAG_ML_MOD_OVERRIDDEN) && s2.mod == MOD_GEOMETRIC, "a more tolerant ML modulation than needed is kept");
    SonarPacket k = buildPacket(d, 1), f = buildPacket(d, 1, MOD_LFM_CHIRP);
    CHECK(k.modulation == d.mod && k.ftwStep == fpgaWave(withModulation(PROFILES[d.profile], d.mod)).ftwStep
          && f.modulation == MOD_LFM_CHIRP, "packet carries the chosen modulation; M overrides it"); }

  printf("== simulated water conditions (water_sim.h) ==\n");
  { watersim::Sim s; watersim::init(s, 7);
    bool inRange = true, rotates = true, speedOk = true, deterministic = true;
    float lastR[3] = { -1, -1, -1 }, lastT = 0;
    int profiles[NUM_PROFILES] = { 0 }, mods[4] = { 0 };
    float tMin = 99, tMax = -99, dMin = 9999, dMax = -1, turbMax = 0;
    watersim::Sim twin; watersim::init(twin, 7);
    for (int i = 0; i < 20000; i++) {
      const watersim::Reading r = watersim::step(s, 1.0f / PING_RATE_HZ);
      const watersim::Reading q = watersim::step(twin, 1.0f / PING_RATE_HZ);
      if (r.rangeM != q.rangeM || r.tempC != q.tempC) deterministic = false;
      Env e = { r.tempC, r.salinityPpt, r.depthM, r.turbidityNtu, r.batteryPct, r.speedMs };
      Env clean = e;
      if (sanitizeEnv(clean) || r.rangeM < MIN_TARGET_RANGE_M || r.rangeM > MAX_TARGET_RANGE_M) inRange = false;
      if (r.contact != i % 3) rotates = false;
      // the speed is the rate the range changes (3 pings = 3 x 1/6 s x SIM_SPEEDUP of mission time apart)
      if (lastR[r.contact] >= 0 && i > 3) {
        const float rate = fabsf(r.rangeM - lastR[r.contact]) / (r.missionS - lastT + 2 * SIM_SPEEDUP / PING_RATE_HZ);
        if (rate > 3.0f * SPEED_MAX_MS) speedOk = false;
      }
      lastR[r.contact] = r.rangeM; lastT = r.missionS;
      tMin = fminf(tMin, r.tempC); tMax = fmaxf(tMax, r.tempC); dMin = fminf(dMin, r.depthM); dMax = fmaxf(dMax, r.depthM);
      turbMax = fmaxf(turbMax, r.turbidityNtu);
      Decision d = decide(e, r.rangeM, -1, -1); chooseModulation(d, e);
      profiles[d.profile]++; mods[d.mod]++;
    }
    int nProf = 0; for (int c : profiles) nProf += c > 0;
    printf("  20000 pings: temperature %.1f..%.1f C, depth %.0f..%.0f m, turbidity up to %.0f NTU, battery %.0f %%,"
           " %d different profiles, LFM %d / geometric %d / BPSK %d\n",
           tMin, tMax, dMin, dMax, turbMax, s.battery, nProf, mods[MOD_LFM_CHIRP], mods[MOD_GEOMETRIC], mods[MOD_BPSK]);
    CHECK(deterministic, "the simulation is repeatable from its seed");
    CHECK(inRange, "every simulated input is inside the valid sensor ranges");
    CHECK(rotates, "pings go to contacts A, B, C in turn");
    CHECK(speedOk, "contacts move at plausible speeds");
    CHECK(tMax - tMin > 10 && dMax - dMin > 250 && nProf >= 3 && mods[MOD_LFM_CHIRP] && mods[MOD_GEOMETRIC] && mods[MOD_BPSK],
          "the conditions change enough to use several profiles and all three modulations"); }

  printf("== ML model (ml_model.h) ==\n");
  { // the C networks against the Python models, on ../ml/test_vectors.csv
    FILE *f = fopen("../ml/test_vectors.csv", "r"); char line[256]; int n = 0, same = 0, close_call = 0, ampOk = 0;
    while (f && fgets(line, sizeof line, f)) {
      float x[6], amp; int k; double margin;
      if (sscanf(line, "%f,%f,%f,%f,%f,%f,%d,%lf,%f", &x[0], &x[1], &x[2], &x[3], &x[4], &x[5], &k, &margin, &amp) != 9) continue;
      n++;
      const int p = ml::ml_predict_profile(x);
      if (p == k) same++;
      else if (margin < 1e-3) close_call++;     // two classes scored almost the same: rounding may flip it
      if (p == k && fabsf(ml::ml_predict_amplitude(x, k) - amp) <= 1e-4f * amp + 1e-6f) ampOk++;
    }
    if (f) fclose(f);
    printf("  vectors=%d  same profile=%d  close calls=%d  same amplitude=%d\n", n, same, close_call, ampOk);
    CHECK(n >= 1000 && same + close_call == n, "C classifier gives the Python model's profile on the test vectors");
    CHECK(ampOk == same, "C amplitude network gives the Python model's amplitude on the test vectors"); }
  { // modulation network, C against Python, on ../ml/test_vectors_mod.csv
    FILE *f = fopen("../ml/test_vectors_mod.csv", "r"); char line[256]; int n = 0, same = 0, close_call = 0;
    while (f && fgets(line, sizeof line, f)) {
      float x[4]; int k, m; double margin;
      if (sscanf(line, "%f,%f,%f,%f,%d,%d,%lf", &x[0], &x[1], &x[2], &x[3], &k, &m, &margin) != 7) continue;
      n++;
      const int p = ml::ml_predict_modulation(x, k);
      if (p == m) same++; else if (margin < 1e-3) close_call++;
    }
    if (f) fclose(f);
    printf("  vectors=%d  same modulation=%d  close calls=%d\n", n, same, close_call);
    CHECK(n >= 1000 && same + close_call == n, "C modulation network gives the Python model's modulation on the test vectors"); }
  { // the ML decides through sonar::decide()
    const float in[6] = { base.tempC, base.salinityPpt, base.depthM, base.turbidityNtu, base.batteryPct, 300.0f };
    const int hint = ml::ml_predict_profile(in);
    const float amp = ml::ml_predict_amplitude(in, hint);
    Decision phys = decide(base, 300, -1, -1);
    Decision d = decide(base, 300, -1, hint, amp);
    CHECK((d.flags & FLAG_ML_USED) && d.profile == phys.profile && d.ampFrac >= phys.ampFrac - 1e-6f
          && d.ampFrac <= phys.ampFrac * 1.2f,
          "base scenario (300 m): the ML's profile and amplitude are used, amplitude enough but not wasteful");
    Decision low = decide(base, 300, -1, phys.profile, 0.0f);
    CHECK((low.flags & FLAG_ML_AMP_RAISED) && fabsf(low.ampFrac - phys.ampFrac) < 1e-6f,
          "an ML amplitude that is too low is raised to what the link needs");
    Env moving = base; moving.speedMs = 2.0f;
    const float mi[4] = { moving.tempC, moving.salinityPpt, moving.depthM, moving.speedMs };
    const int mm = ml::ml_predict_modulation(mi, d.profile);
    chooseModulation(d, moving, mm);
    CHECK(mm == modulationFor(d.dopplerCycles) && d.mod == mm && !(d.flags & FLAG_ML_MOD_OVERRIDDEN),
          "base scenario at 2 m/s: the ML's modulation is the rule's and is used"); }

  if (argc > 1) {
    printf("== C++ vs Python reference (%s) ==\n", argv[1]);
    FILE *f = fopen(argv[1], "r"); char line[512]; int n = 0, profMis = 0, ampBad = 0, snrBad = 0, modMis = 0; double maxSnr = 0, maxAmp = 0;
    while (f && fgets(line, sizeof line, f)) {
      double T, S, D, tb, soc, R, ea, es, v; int prev, ep, eok, em;
      if (sscanf(line, "%lf,%lf,%lf,%lf,%lf,%lf,%d,%d,%d,%lf,%lf,%lf,%d", &T, &S, &D, &tb, &soc, &R, &prev, &ep, &eok, &ea, &es, &v, &em) != 13) continue;
      Env e = { (float)T, (float)S, (float)D, (float)tb, (float)soc, (float)v };
      Decision d = decide(e, (float)R, prev, -1); n++;
      if (d.profile != ep) { profMis++; continue; }
      chooseModulation(d, e);
      if (d.mod != em) modMis++;
      double da = fabs(d.ampFrac - ea), ds = fabs(d.snrOutDb - es);
      if (da > maxAmp) { maxAmp = da; }
      if (ds > maxSnr) { maxSnr = ds; }
      if (da > 2e-3) { ampBad++; }
      if (ds > 0.02) { snrBad++; }
    }
    if (f) fclose(f);
    printf("  vectors=%d  profile mismatches=%d (%.3f%%)  amp>2e-3: %d  snr>0.02dB: %d  max|d amp|=%.2e max|d snr|=%.2e dB"
           "  modulation mismatches=%d\n", n, profMis, 100.0 * profMis / (n ? n : 1), ampBad, snrBad, maxAmp, maxSnr, modMis);
    CHECK(n >= 4000, "reference vectors loaded");
    CHECK(profMis <= n / 200, "profile choice matches Python (<=0.5% float/double boundary flips)");
    CHECK(ampBad == 0 && snrBad == 0, "amplitude and SNR match Python within tolerance");
    CHECK(modMis <= n / 1000, "modulation choice matches Python (<=0.1% float/double boundary flips)");
  }
  printf("\n%s (%d failures)\n", fails ? "TESTS FAILED" : "ALL TESTS PASSED", fails);
  return fails ? 1 : 0;
}
