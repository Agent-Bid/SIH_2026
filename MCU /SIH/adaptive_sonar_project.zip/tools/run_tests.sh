#!/bin/bash
# Host-side verification: Python reference vs C++ core. Needs python3 + g++.
set -e
cd "$(dirname "$0")"
python3 make_vectors.py
g++ -std=c++11 -O1 -Wall -Wextra -I../adaptive_sonar test_core.cpp -o test_core
./test_core vectors.csv
# the sketch itself must compile with and without the ML model (mock Arduino/FreeRTOS headers)
for ml in 0 1; do
  g++ -std=c++11 -fsyntax-only -Wall -Wextra -Imock -I../adaptive_sonar -DUSE_ML_MODEL=$ml -x c++ ../adaptive_sonar/adaptive_sonar.ino
done
echo "sketch type-checks with USE_ML_MODEL 0 and 1"
